import { supabase } from "./client";

export type OmdbSeriesDetails = any;

export type OmdbListType = "trending" | "popular" | "top_rated" | "upcoming";

export interface OmdbSeriesSummary {
  id: number;
  imdb_id?: string;
  name: string;
  title?: string; // For movies
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  vote_average: number;
  first_air_date?: string;
  release_date?: string; // For movies
  media_type?: 'tv' | 'movie';
  year?: string;
}

export interface OmdbDiscoverResponse {
  page: number;
  results: OmdbSeriesSummary[];
  total_pages: number;
  total_results: number;
}

/**
 * Calls the `omdb-series` Supabase Edge Function to fetch series metadata from OMDB.
 * Optionally syncs into your Supabase database.
 * Note: seriesId can be an IMDb ID (e.g., "tt0944947") or numeric ID
 */
export async function fetchTmdbSeriesDetails(
  seriesId: number | string,
  options?: { language?: string; sync?: boolean },
): Promise<OmdbSeriesDetails | null> {
  const { sync = false } = options ?? {};

  try {
    // Convert numeric ID to IMDb ID format if needed
    let imdbId = seriesId.toString();
    if (!imdbId.startsWith("tt")) {
      imdbId = `tt${imdbId.padStart(7, "0")}`;
    }

    const { data, error } = await supabase.functions.invoke("omdb-series", {
      body: { seriesId: imdbId, sync },
    });

    if (error) {
      console.error(`OMDB API error for series ${seriesId}:`, error);
      return null;
    }

    return data as OmdbSeriesDetails;
  } catch (err) {
    console.error(`Failed to fetch OMDB series details for ${seriesId}:`, err);
    return null;
  }
}

/**
 * Calls the `omdb-discover` Supabase Edge Function to fetch lists of series
 * for homepage sections like Trending, Popular, Top Rated, Upcoming.
 * Note: OMDB doesn't have native trending/popular endpoints, so we use curated lists.
 */
export async function fetchTmdbSeriesList(
  type: OmdbListType,
  options?: { page?: number; language?: string; mediaType?: 'tv' | 'movie' | 'all' },
): Promise<OmdbDiscoverResponse> {
  const { page = 1, mediaType = 'all', language = 'all' } = options ?? {};

  try {
  const { data, error } = await supabase.functions.invoke("omdb-discover", {
    body: { type, page, mediaType, language },
  });

    if (error) {
      console.error(`OMDB API error for ${type}:`, error);
      return {
        page: 1,
        results: [],
        total_pages: 0,
        total_results: 0,
      };
    }

    // Validate response structure
    if (!data || !Array.isArray(data.results)) {
      console.warn(`Invalid OMDB response for ${type}:`, data);
      return {
        page: 1,
        results: [],
        total_pages: 0,
        total_results: 0,
      };
    }

    return data as OmdbDiscoverResponse;
  } catch (err) {
    console.error(`Failed to fetch OMDB data for ${type}:`, err);
    return {
      page: 1,
      results: [],
      total_pages: 0,
      total_results: 0,
    };
  }
}

/**
 * Fetches movie details from OMDB API
 * Note: movieId can be an IMDb ID (e.g., "tt1375666") or numeric ID
 */
export async function fetchTmdbMovieDetails(
  movieId: number | string,
  options?: { language?: string },
): Promise<OmdbSeriesDetails | null> {
  try {
    // Convert numeric ID to IMDb ID format if needed
    let imdbId = movieId.toString();
    if (!imdbId.startsWith("tt")) {
      imdbId = `tt${imdbId.padStart(7, "0")}`;
    }

    const { data, error } = await supabase.functions.invoke("omdb-movie", {
      body: { movieId: imdbId },
    });

    if (error) {
      console.error(`OMDB API error for movie ${movieId}:`, error);
      return null;
    }

    return data as OmdbSeriesDetails;
  } catch (err) {
    console.error(`Failed to fetch OMDB movie details for ${movieId}:`, err);
    return null;
  }
}

/**
 * Fetches season episodes from OMDB API
 */
export async function fetchSeasonEpisodes(
  seriesId: number | string,
  seasonNumber: number,
): Promise<any | null> {
  try {
    // Convert numeric ID to IMDb ID format if needed
    let imdbId = seriesId.toString();
    if (!imdbId.startsWith("tt")) {
      imdbId = `tt${imdbId.padStart(7, "0")}`;
    }

    const { data, error } = await supabase.functions.invoke("omdb-episodes", {
      body: { seriesId: imdbId, seasonNumber },
    });

    if (error) {
      console.error(`OMDB API error for season ${seasonNumber}:`, error);
      return null;
    }

    return data;
  } catch (err) {
    console.error(`Failed to fetch OMDB season episodes:`, err);
    return null;
  }
}

/**
 * Searches TV series and movies by name using OMDB API
 * Returns combined results from both TV and movies
 */
export async function searchTmdbSeries(
  query: string,
  options?: { page?: number; language?: string; category?: string },
): Promise<OmdbDiscoverResponse> {
  const { page = 1, language = "all", category = "all" } = options ?? {};

  try {
    if (!query || query.trim().length === 0) {
      console.warn("Empty search query provided");
      return {
        page: 1,
        results: [],
        total_pages: 0,
        total_results: 0,
      };
    }

    const { data, error } = await supabase.functions.invoke("omdb-search", {
      body: { query: query.trim(), page, language, category },
    });

    if (error) {
      console.error(`OMDB search error for "${query}":`, error);
      return {
        page: 1,
        results: [],
        total_pages: 0,
        total_results: 0,
      };
    }

    if (!data) {
      console.warn(`No data returned from search for "${query}"`);
      return {
        page: 1,
        results: [],
        total_pages: 0,
        total_results: 0,
      };
    }

    if (!Array.isArray(data.results)) {
      console.warn(`Invalid results format for "${query}":`, data);
      return {
        page: 1,
        results: [],
        total_pages: 0,
        total_results: 0,
      };
    }

    console.log(`Search successful for "${query}": ${data.results.length} results`);
    return data as OmdbDiscoverResponse;
  } catch (err) {
    console.error(`Failed to search OMDB for "${query}":`, err);
    return {
      page: 1,
      results: [],
      total_pages: 0,
      total_results: 0,
    };
  }
}

