import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { fetchTmdbSeriesList } from "@/integrations/supabase/tmdb";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Globe, Film, Tv } from "lucide-react";

const LANGUAGES = [
  { code: "all", name: "All Languages" },
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "zh", name: "Chinese" },
  { code: "pt", name: "Portuguese" },
  { code: "it", name: "Italian" },
  { code: "ru", name: "Russian" },
  { code: "ar", name: "Arabic" },
  { code: "tr", name: "Turkish" },
];

const CATEGORIES = [
  { value: "all", label: "All Categories" },
  { value: "action", label: "Action" },
  { value: "adventure", label: "Adventure" },
  { value: "animation", label: "Animation" },
  { value: "comedy", label: "Comedy" },
  { value: "crime", label: "Crime" },
  { value: "documentary", label: "Documentary" },
  { value: "drama", label: "Drama" },
  { value: "family", label: "Family" },
  { value: "fantasy", label: "Fantasy" },
  { value: "history", label: "History" },
  { value: "horror", label: "Horror" },
  { value: "mystery", label: "Mystery" },
  { value: "romance", label: "Romance" },
  { value: "sci-fi", label: "Sci-Fi" },
  { value: "thriller", label: "Thriller" },
  { value: "war", label: "War" },
  { value: "western", label: "Western" },
];

const MediaCard = ({ item, index }: { item: any; index: number }) => {
  const displayName = item.name || item.title || "Unknown";
  const displayYear = item.first_air_date?.substring(0, 4) || item.release_date?.substring(0, 4);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.02 }}
    >
      <Link to={`/${item.media_type === "movie" ? "movie" : "series"}/${item.id}`}>
        <Card className="overflow-hidden hover:scale-[1.02] transition-transform cursor-pointer border-border group">
          <CardContent className="p-0">
            <div className="aspect-[2/3] relative bg-muted overflow-hidden">
              {item.poster_path ? (
                <img
                  src={item.poster_path}
                  alt={displayName}
                  className="h-full w-full object-cover group-hover:brightness-110 transition-all"
                  loading="lazy"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = "none";
                  }}
                />
              ) : (
                <div className="h-full w-full bg-muted flex items-center justify-center">
                  <p className="text-muted-foreground text-xs text-center px-2">{displayName}</p>
                </div>
              )}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-2 space-y-1">
                <p className="text-xs font-semibold text-white line-clamp-2">{displayName}</p>
                <div className="flex items-center justify-between text-[10px] text-white/80">
                  <span>⭐ {item.vote_average?.toFixed(1) || "N/A"}</span>
                  <span className="uppercase text-[9px] flex items-center gap-1">
                    {item.media_type === "movie" ? (
                      <>
                        <Film className="h-3 w-3" /> Movie
                      </>
                    ) : (
                      <>
                        <Tv className="h-3 w-3" /> TV
                      </>
                    )}
                  </span>
                  {displayYear && <span>{displayYear}</span>}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
};

const ContentSection = ({
  title,
  type,
  mediaType,
  language,
  category,
}: {
  title: string;
  type: "trending" | "popular" | "top_rated" | "upcoming" | "now_playing";
  mediaType: "tv" | "movie" | "all";
  language: string;
  category: string;
}) => {
  const { data, isLoading, error } = useQuery({
    queryKey: ["tmdb", type, mediaType, language, category],
    queryFn: () =>
      fetchTmdbSeriesList(type, {
        mediaType,
        language,
        category,
      }),
    staleTime: 1000 * 60 * 60,
    retry: 3,
    refetchOnWindowFocus: false,
  });

  if (isLoading) {
    return (
      <section className="space-y-4">
        <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="overflow-hidden border-border">
              <CardContent className="p-0">
                <Skeleton className="aspect-[2/3] w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    );
  }

  const items = data?.results || [];

  return (
    <section className="space-y-4">
      <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
      {items.length === 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="overflow-hidden border-border opacity-50">
              <CardContent className="p-0">
                <div className="aspect-[2/3] bg-muted flex items-center justify-center">
                  <p className="text-muted-foreground text-xs text-center px-2">No content</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {items.slice(0, 12).map((item, index) => (
            <MediaCard key={`${item.id}-${item.media_type}`} item={item} index={index} />
          ))}
        </div>
      )}
    </section>
  );
};

const Index = () => {
  const [selectedLanguage, setSelectedLanguage] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<string>("all");

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8 space-y-12">
        <motion.section
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold">CineVerse</h1>
              <p className="text-muted-foreground max-w-2xl text-lg mt-2">
                The universe of movies and series—organized for you. Discover, track, and share your favorites with real-time
                TMDB data, personalized watchlists, and social features.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-muted-foreground" />
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Language" />
                  </SelectTrigger>
                  <SelectContent>
                    {LANGUAGES.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </motion.section>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="all" className="flex items-center gap-2">
              All
            </TabsTrigger>
            <TabsTrigger value="movies" className="flex items-center gap-2">
              <Film className="h-4 w-4" /> Movies
            </TabsTrigger>
            <TabsTrigger value="series" className="flex items-center gap-2">
              <Tv className="h-4 w-4" /> Series
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-12 mt-8">
            <ContentSection
              title="Popular Movies & Series"
              type="popular"
              mediaType="all"
              language={selectedLanguage}
              category={selectedCategory}
            />
            <ContentSection
              title="Top Rated"
              type="top_rated"
              mediaType="all"
              language={selectedLanguage}
              category={selectedCategory}
            />
            <ContentSection
              title="Now Playing & Airing"
              type="now_playing"
              mediaType="all"
              language={selectedLanguage}
              category={selectedCategory}
            />
          </TabsContent>

          <TabsContent value="movies" className="space-y-12 mt-8">
            <ContentSection
              title="Popular Movies"
              type="popular"
              mediaType="movie"
              language={selectedLanguage}
              category={selectedCategory}
            />
            <ContentSection
              title="Top Rated Movies"
              type="top_rated"
              mediaType="movie"
              language={selectedLanguage}
              category={selectedCategory}
            />
            <ContentSection
              title="Now Playing in Theaters"
              type="now_playing"
              mediaType="movie"
              language={selectedLanguage}
              category={selectedCategory}
            />
            <ContentSection
              title="Upcoming Movies"
              type="upcoming"
              mediaType="movie"
              language={selectedLanguage}
              category={selectedCategory}
            />
          </TabsContent>

          <TabsContent value="series" className="space-y-12 mt-8">
            <ContentSection
              title="Popular TV Series"
              type="popular"
              mediaType="tv"
              language={selectedLanguage}
              category={selectedCategory}
            />
            <ContentSection
              title="Top Rated Series"
              type="top_rated"
              mediaType="tv"
              language={selectedLanguage}
              category={selectedCategory}
            />
            <ContentSection
              title="Currently Airing"
              type="now_playing"
              mediaType="tv"
              language={selectedLanguage}
              category={selectedCategory}
            />
            <ContentSection
              title="On The Air"
              type="upcoming"
              mediaType="tv"
              language={selectedLanguage}
              category={selectedCategory}
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Index;
