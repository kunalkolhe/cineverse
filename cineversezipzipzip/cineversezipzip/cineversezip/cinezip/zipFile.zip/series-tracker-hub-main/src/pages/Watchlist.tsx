import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { fetchTmdbSeriesDetails, fetchTmdbMovieDetails } from "@/integrations/supabase/tmdb";
import { toast } from "sonner";
import { X, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { normalizeImageUrl } from "@/lib/utils";

// OMDB provides direct poster URLs

const Watchlist = () => {
  const navigate = useNavigate();
  const [watchlistIds, setWatchlistIds] = useState<number[]>([]);

  useEffect(() => {
    loadWatchlist();
  }, []);

  const loadWatchlist = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      navigate("/auth");
      return;
    }

    const { data, error } = await supabase
      .from("user_watchlist")
      .select("series_id")
      .eq("user_id", user.id);

    if (!error && data) {
      setWatchlistIds(data.map((item) => item.series_id));
    }
  };

  const handleRemove = async (seriesId: number) => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase
      .from("user_watchlist")
      .delete()
      .eq("user_id", user.id)
      .eq("series_id", seriesId);

    if (!error) {
      setWatchlistIds(watchlistIds.filter((id) => id !== seriesId));
      toast.success("Removed from watchlist");
    }
  };

  const { data: watchlistData, isLoading } = useQuery({
    queryKey: ["watchlist", watchlistIds],
    queryFn: async () => {
      // Try to fetch as series first, then as movie if it fails
      const promises = watchlistIds.map(async (id) => {
        const series = await fetchTmdbSeriesDetails(id);
        if (series) {
          return { ...series, media_type: 'tv' };
        }
        const movie = await fetchTmdbMovieDetails(id);
        if (movie) {
          return { ...movie, media_type: 'movie' };
        }
        return null;
      });
      const results = await Promise.all(promises);
      return results.filter((item) => item !== null);
    },
    enabled: watchlistIds.length > 0,
    retry: 1,
    refetchOnWindowFocus: false,
  });

  if (watchlistIds.length === 0 && !isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold mb-6">My Watchlist</h1>
          <Card>
            <CardContent className="p-12 text-center">
              <p className="text-muted-foreground text-lg">
                Your watchlist is empty. Start adding series to track them!
              </p>
              <Button className="mt-4" onClick={() => navigate("/")}>
                Browse Series
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8 space-y-6">
        <h1 className="text-3xl font-bold">My Watchlist</h1>
        {isLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="overflow-hidden border-border">
                <CardContent className="p-0">
                  <Skeleton className="aspect-[2/3] w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {watchlistData?.map((series, index) => (
              <motion.div
                key={series.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
              >
                <Card className="overflow-hidden hover:scale-[1.02] transition-transform border-border group relative">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80"
                    onClick={() => handleRemove(series.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                  <Link to={`/${series.media_type === 'movie' ? 'movie' : 'series'}/${series.id}`}>
                    <CardContent className="p-0">
                      <div className="aspect-[2/3] relative">
                        {normalizeImageUrl(series.poster_path) ? (
                          <img
                            src={normalizeImageUrl(series.poster_path)!}
                            alt={series.name}
                            className="h-full w-full object-cover group-hover:brightness-110 transition-all"
                            loading="lazy"
                          />
                        ) : (
                          <div className="h-full w-full bg-muted flex items-center justify-center">
                            <p className="text-muted-foreground text-xs text-center px-2">
                              {series.name || series.title}
                            </p>
                          </div>
                        )}
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-2 space-y-1">
                          <p className="text-xs font-semibold text-white line-clamp-2">
                            {series.name || series.title}
                          </p>
                          <div className="flex items-center justify-between text-[10px] text-white/80">
                            <span>⭐ {series.vote_average?.toFixed(1) || "N/A"}</span>
                            <span className="uppercase text-[9px]">
                              {series.media_type === 'movie' ? 'Movie' : 'TV'}
                            </span>
                            {(series.first_air_date || series.release_date) && (
                              <span>{new Date(series.first_air_date || series.release_date!).getFullYear()}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Link>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Watchlist;

