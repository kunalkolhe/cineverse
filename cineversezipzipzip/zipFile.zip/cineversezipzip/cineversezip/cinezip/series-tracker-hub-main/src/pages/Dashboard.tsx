import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import { Session } from "@supabase/supabase-js";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { Play, Clock, Star, TrendingUp, Eye, BookmarkPlus, Film, Tv } from "lucide-react";
import { motion } from "framer-motion";
import { normalizeImageUrl } from "@/lib/utils";
import { getWatchlist, getWatchlistStats, WatchlistItem } from "@/lib/watchlist";

const Dashboard = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>([]);
  const [stats, setStats] = useState({
    total: 0,
    planned: 0,
    watched: 0,
    movies: 0,
    series: 0,
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        loadUserData();
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        loadUserData();
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const loadUserData = () => {
    const items = getWatchlist();
    setWatchlist(items);
    setStats(getWatchlistStats());
  };

  const planToWatchItems = watchlist.filter((i) => i.status === "planned").slice(0, 6);
  const watchedItems = watchlist.filter((i) => i.status === "watched").slice(0, 6);

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8 space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold mb-2">My Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here's your activity overview.</p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total in Watchlist</p>
                  <p className="text-2xl font-bold">{stats.total}</p>
                </div>
                <Play className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Plan to Watch</p>
                  <p className="text-2xl font-bold">{stats.planned}</p>
                </div>
                <BookmarkPlus className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Already Watched</p>
                  <p className="text-2xl font-bold">{stats.watched}</p>
                </div>
                <Eye className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Movies / Series</p>
                  <p className="text-2xl font-bold">{stats.movies} / {stats.series}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold flex items-center gap-2">
                <BookmarkPlus className="h-6 w-6" /> Plan to Watch
              </h2>
              {planToWatchItems.length > 0 && (
                <Link to="/watchlist" className="text-primary hover:underline text-sm">
                  View All
                </Link>
              )}
            </div>
            {planToWatchItems.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                {planToWatchItems.map((item) => (
                  <Link key={`${item.id}-${item.media_type}`} to={`/${item.media_type === "movie" ? "movie" : "series"}/${item.id}`}>
                    <Card className="overflow-hidden hover:scale-[1.02] transition-transform cursor-pointer border-border">
                      <CardContent className="p-0">
                        <div className="aspect-[2/3] relative">
                          {normalizeImageUrl(item.poster_path) ? (
                            <img
                              src={normalizeImageUrl(item.poster_path)!}
                              alt={item.name}
                              className="h-full w-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <div className="h-full w-full bg-muted flex items-center justify-center">
                              <p className="text-muted-foreground text-xs text-center px-2">
                                {item.name}
                              </p>
                            </div>
                          )}
                          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-2">
                            <p className="text-xs font-semibold text-white line-clamp-2">{item.name}</p>
                            <div className="flex items-center gap-2 text-[10px] text-white/80 mt-1">
                              {item.media_type === "movie" ? (
                                <Film className="h-3 w-3" />
                              ) : (
                                <Tv className="h-3 w-3" />
                              )}
                              <span>⭐ {item.vote_average?.toFixed(1)}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-muted-foreground">No items in your plan to watch list yet.</p>
                  <Link to="/">
                    <button className="mt-4 px-4 py-2 bg-primary text-primary-foreground rounded-md">
                      Browse Content
                    </button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold flex items-center gap-2">
                <Eye className="h-6 w-6" /> Already Watched
              </h2>
              {watchedItems.length > 0 && (
                <Link to="/watchlist" className="text-primary hover:underline text-sm">
                  View All
                </Link>
              )}
            </div>
            {watchedItems.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                {watchedItems.map((item) => (
                  <Link key={`${item.id}-${item.media_type}`} to={`/${item.media_type === "movie" ? "movie" : "series"}/${item.id}`}>
                    <Card className="overflow-hidden hover:scale-[1.02] transition-transform cursor-pointer border-border">
                      <CardContent className="p-0">
                        <div className="aspect-[2/3] relative">
                          {normalizeImageUrl(item.poster_path) ? (
                            <img
                              src={normalizeImageUrl(item.poster_path)!}
                              alt={item.name}
                              className="h-full w-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <div className="h-full w-full bg-muted flex items-center justify-center">
                              <p className="text-muted-foreground text-xs text-center px-2">
                                {item.name}
                              </p>
                            </div>
                          )}
                          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-2">
                            <p className="text-xs font-semibold text-white line-clamp-2">{item.name}</p>
                            <div className="flex items-center gap-2 text-[10px] text-white/80 mt-1">
                              {item.media_type === "movie" ? (
                                <Film className="h-3 w-3" />
                              ) : (
                                <Tv className="h-3 w-3" />
                              )}
                              <span>⭐ {item.vote_average?.toFixed(1)}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-8 text-center">
                  <p className="text-muted-foreground">No items marked as watched yet.</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
