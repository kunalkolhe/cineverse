import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import { Session } from "@supabase/supabase-js";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { fetchTmdbSeriesDetails } from "@/integrations/supabase/tmdb";
import { Link } from "react-router-dom";
import { Play, Clock, Star, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";
import { normalizeImageUrl } from "@/lib/utils";

const TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p/w500";

const Dashboard = () => {
  const navigate = useNavigate();
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [watchlistIds, setWatchlistIds] = useState<number[]>([]);
  const [watchHistory, setWatchHistory] = useState<any[]>([]);
  const [stats, setStats] = useState({
    totalWatched: 0,
    totalSeries: 0,
    averageRating: 0,
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        loadUserData();
      }
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (!session) {
        navigate("/auth");
      } else {
        loadUserData();
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const loadUserData = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    // Load watchlist
    const { data: watchlist } = await supabase
      .from("user_watchlist")
      .select("series_id")
      .eq("user_id", user.id);

    if (watchlist) {
      setWatchlistIds(watchlist.map((w) => w.series_id));
    }

    // Load watch history
    const { data: history } = await supabase
      .from("user_watch_history")
      .select("*, episodes(series_id)")
      .eq("user_id", user.id)
      .order("watched_at", { ascending: false })
      .limit(10);

    if (history) {
      setWatchHistory(history);
      setStats({
        totalWatched: history.length,
        totalSeries: new Set(history.map((h) => h.episodes?.series_id).filter(Boolean)).size,
        averageRating: 0, // Calculate from ratings
      });
    }
  };

  const { data: continueWatching, isLoading: isLoadingContinue } = useQuery({
    queryKey: ["continue-watching", watchlistIds.slice(0, 6)],
    queryFn: async () => {
      const promises = watchlistIds.slice(0, 6).map((id) => fetchTmdbSeriesDetails(id));
      const results = await Promise.all(promises);
      // Filter out null results
      return results.filter((series) => series !== null);
    },
    enabled: watchlistIds.length > 0,
    retry: 1,
    refetchOnWindowFocus: false,
  });

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-[calc(100vh-80px)]">
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8 space-y-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold mb-2">My Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here's your activity overview.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Episodes Watched</p>
                  <p className="text-2xl font-bold">{stats.totalWatched}</p>
                </div>
                <Play className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Series Tracked</p>
                  <p className="text-2xl font-bold">{stats.totalSeries}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Average Rating</p>
                  <p className="text-2xl font-bold">{stats.averageRating.toFixed(1)}</p>
                </div>
                <Star className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Watchlist</p>
                  <p className="text-2xl font-bold">{watchlistIds.length}</p>
                </div>
                <Clock className="h-8 w-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-semibold mb-4">Continue Watching</h2>
            {isLoadingContinue ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="overflow-hidden border-border">
                    <CardContent className="p-0">
                      <Skeleton className="aspect-[2/3] w-full" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : continueWatching && continueWatching.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                {continueWatching.map((series) => (
                  <Link key={series.id} to={`/series/${series.id}`}>
                    <Card className="overflow-hidden hover:scale-[1.02] transition-transform cursor-pointer border-border">
                      <CardContent className="p-0">
                        <div className="aspect-[2/3] relative">
                          {normalizeImageUrl(series.poster_path) ? (
                            <img
                              src={normalizeImageUrl(series.poster_path)!}
                              alt={series.name}
                              className="h-full w-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <div className="h-full w-full bg-muted flex items-center justify-center">
                              <p className="text-muted-foreground text-xs text-center px-2">
                                {series.name}
                              </p>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <p className="text-muted-foreground">No series in progress yet</p>
                  <Link to="/">
                    <button className="mt-4 px-4 py-2 bg-primary text-primary-foreground rounded-md">
                      Browse Series
                    </button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            <h2 className="text-2xl font-semibold mb-4">Recent Activity</h2>
            <Card>
              <CardContent className="p-6">
                {watchHistory.length > 0 ? (
                  <div className="space-y-4">
                    {watchHistory.slice(0, 5).map((item) => (
                      <div key={item.id} className="flex items-center justify-between p-3 rounded border border-border">
                        <div>
                          <p className="font-medium">Watched an episode</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(item.watched_at).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-muted-foreground">No watch history yet</p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
