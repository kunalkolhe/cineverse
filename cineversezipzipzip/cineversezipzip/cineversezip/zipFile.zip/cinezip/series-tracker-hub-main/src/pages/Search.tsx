import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { searchTmdbSeries } from "@/integrations/supabase/tmdb";
import { Link } from "react-router-dom";
import { Search as SearchIcon, Globe, Film, Tv } from "lucide-react";
import { motion } from "framer-motion";
import { toast } from "sonner";

const LANGUAGES = [
  { code: "all", name: "All Languages" },
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "zh", name: "Chinese" },
  { code: "pt", name: "Portuguese" },
  { code: "it", name: "Italian" },
  { code: "ru", name: "Russian" },
  { code: "ar", name: "Arabic" },
  { code: "tr", name: "Turkish" },
];

const CATEGORIES = [
  { value: "all", label: "All Categories" },
  { value: "action", label: "Action" },
  { value: "adventure", label: "Adventure" },
  { value: "animation", label: "Animation" },
  { value: "comedy", label: "Comedy" },
  { value: "crime", label: "Crime" },
  { value: "documentary", label: "Documentary" },
  { value: "drama", label: "Drama" },
  { value: "family", label: "Family" },
  { value: "fantasy", label: "Fantasy" },
  { value: "history", label: "History" },
  { value: "horror", label: "Horror" },
  { value: "mystery", label: "Mystery" },
  { value: "romance", label: "Romance" },
  { value: "sci-fi", label: "Sci-Fi" },
  { value: "thriller", label: "Thriller" },
  { value: "war", label: "War" },
  { value: "western", label: "Western" },
];

const Search = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get("q") || "");
  const [selectedLanguage, setSelectedLanguage] = useState<string>(searchParams.get("lang") || "all");
  const [selectedCategory, setSelectedCategory] = useState<string>(searchParams.get("cat") || "all");
  const [mediaFilter, setMediaFilter] = useState<string>("all");

  const { data, isLoading, error } = useQuery({
    queryKey: ["tmdb-search", query, selectedLanguage, selectedCategory],
    queryFn: async () => {
      if (!query || query.trim().length === 0) {
        return { page: 1, results: [], total_pages: 0, total_results: 0 };
      }
      return searchTmdbSeries(query.trim(), {
        language: selectedLanguage,
        category: selectedCategory,
      });
    },
    enabled: query.trim().length > 2,
    staleTime: 1000 * 60 * 5,
    retry: 2,
    retryDelay: 1000,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    const q = searchParams.get("q");
    const lang = searchParams.get("lang") || "all";
    const cat = searchParams.get("cat") || "all";
    if (q && q !== query) {
      setQuery(q);
    }
    if (lang !== selectedLanguage) {
      setSelectedLanguage(lang);
    }
    if (cat !== selectedCategory) {
      setSelectedCategory(cat);
    }
  }, [searchParams]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedQuery = query.trim();
    if (trimmedQuery.length > 2) {
      setSearchParams({
        q: trimmedQuery,
        lang: selectedLanguage,
        cat: selectedCategory,
      });
    } else if (trimmedQuery.length > 0) {
      toast.info("Please enter at least 3 characters to search");
    }
  };

  useEffect(() => {
    if (query.trim().length > 2) {
      const currentQ = searchParams.get("q");
      const currentLang = searchParams.get("lang") || "all";
      const currentCat = searchParams.get("cat") || "all";

      if (currentQ !== query.trim() || currentLang !== selectedLanguage || currentCat !== selectedCategory) {
        setSearchParams({
          q: query.trim(),
          lang: selectedLanguage,
          cat: selectedCategory,
        });
      }
    }
  }, [selectedLanguage, selectedCategory]);

  const filteredResults = data?.results?.filter((item) => {
    if (mediaFilter === "all") return true;
    return item.media_type === mediaFilter;
  }) || [];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8 space-y-8">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold">Search Movies & Series</h1>
          <form onSubmit={handleSearch} className="max-w-2xl space-y-4">
            <div className="relative">
              <SearchIcon className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search by title..."
                className="pl-10 h-12 text-lg"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-muted-foreground" />
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Language" />
                  </SelectTrigger>
                  <SelectContent>
                    {LANGUAGES.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </form>

          {query.trim().length > 2 && data && data.results && data.results.length > 0 && (
            <Tabs value={mediaFilter} onValueChange={setMediaFilter} className="w-full max-w-md">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="all">All ({data.results.length})</TabsTrigger>
                <TabsTrigger value="movie" className="flex items-center gap-1">
                  <Film className="h-4 w-4" /> Movies ({data.results.filter((r) => r.media_type === "movie").length})
                </TabsTrigger>
                <TabsTrigger value="tv" className="flex items-center gap-1">
                  <Tv className="h-4 w-4" /> Series ({data.results.filter((r) => r.media_type === "tv").length})
                </TabsTrigger>
              </TabsList>
            </Tabs>
          )}
        </motion.div>

        {query.length <= 2 && <p className="text-muted-foreground">Type at least 3 characters to search</p>}

        {isLoading && query.length > 2 && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[...Array(12)].map((_, i) => (
              <Card key={i} className="overflow-hidden border-border">
                <CardContent className="p-0">
                  <Skeleton className="aspect-[2/3] w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {error && query.length > 2 && (
          <div className="space-y-2">
            <p className="text-muted-foreground">Unable to search. Please check your connection.</p>
          </div>
        )}

        {!error && data && query.trim().length > 2 && (
          <>
            {data.total_results > 0 && (
              <p className="text-muted-foreground">
                Found {filteredResults.length} result{filteredResults.length !== 1 ? "s" : ""}
                {mediaFilter !== "all" && ` (filtered from ${data.total_results})`}
              </p>
            )}
            {filteredResults.length === 0 ? (
              <div className="space-y-2">
                <p className="text-muted-foreground">No results found for "{query}"</p>
                <p className="text-sm text-muted-foreground">
                  Try searching with a different term or check your spelling.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {filteredResults.map((series, index) => {
                  const displayName = series.name || series.title || "Unknown";
                  const displayYear =
                    series.first_air_date?.substring(0, 4) || series.release_date?.substring(0, 4);

                  return (
                    <motion.div
                      key={`${series.id}-${series.media_type}-${index}`}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <Link to={`/${series.media_type === "movie" ? "movie" : "series"}/${series.id}`}>
                        <Card className="overflow-hidden hover:scale-[1.02] transition-transform cursor-pointer border-border group">
                          <CardContent className="p-0">
                            <div className="aspect-[2/3] relative">
                              {series.poster_path ? (
                                <img
                                  src={series.poster_path}
                                  alt={displayName}
                                  className="h-full w-full object-cover group-hover:brightness-110 transition-all"
                                  loading="lazy"
                                  onError={(e) => {
                                    const target = e.target as HTMLImageElement;
                                    target.style.display = "none";
                                  }}
                                />
                              ) : (
                                <div className="h-full w-full bg-muted flex items-center justify-center">
                                  <p className="text-muted-foreground text-xs text-center px-2">{displayName}</p>
                                </div>
                              )}
                              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-2 space-y-1">
                                <p className="text-xs font-semibold text-white line-clamp-2">{displayName}</p>
                                <div className="flex items-center justify-between text-[10px] text-white/80">
                                  <span>⭐ {series.vote_average?.toFixed(1) || "N/A"}</span>
                                  <span className="uppercase text-[9px] flex items-center gap-1">
                                    {series.media_type === "movie" ? (
                                      <>
                                        <Film className="h-3 w-3" /> Movie
                                      </>
                                    ) : (
                                      <>
                                        <Tv className="h-3 w-3" /> TV
                                      </>
                                    )}
                                  </span>
                                  {displayYear && <span>{displayYear}</span>}
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default Search;
