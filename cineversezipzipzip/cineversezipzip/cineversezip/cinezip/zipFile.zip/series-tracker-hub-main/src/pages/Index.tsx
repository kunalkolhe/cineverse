import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { fetchTmdbSeriesList } from "@/integrations/supabase/tmdb";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Globe } from "lucide-react";
import { normalizeImageUrl, matchesLanguage } from "@/lib/utils";

// OMDB provides direct poster URLs, no base URL needed

// Popular languages for filtering
const LANGUAGES = [
  { code: "all", name: "All Languages" },
  { code: "en", name: "English" },
  { code: "hi", name: "Hindi" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "zh", name: "Chinese" },
  { code: "pt", name: "Portuguese" },
  { code: "it", name: "Italian" },
  { code: "ru", name: "Russian" },
  { code: "ar", name: "Arabic" },
  { code: "tr", name: "Turkish" },
];

const CATEGORIES = [
  { value: "all", label: "All Categories" },
  { value: "action", label: "Action" },
  { value: "adventure", label: "Adventure" },
  { value: "animation", label: "Animation" },
  { value: "biography", label: "Biography" },
  { value: "comedy", label: "Comedy" },
  { value: "crime", label: "Crime" },
  { value: "documentary", label: "Documentary" },
  { value: "drama", label: "Drama" },
  { value: "family", label: "Family" },
  { value: "fantasy", label: "Fantasy" },
  { value: "history", label: "History" },
  { value: "horror", label: "Horror" },
  { value: "mystery", label: "Mystery" },
  { value: "romance", label: "Romance" },
  { value: "sci-fi", label: "Sci-Fi" },
  { value: "thriller", label: "Thriller" },
  { value: "war", label: "War" },
  { value: "western", label: "Western" },
];

const SeriesSection = ({
  title,
  type,
  language,
  category,
}: {
  title: string;
  type: "trending" | "popular" | "top_rated" | "upcoming";
  language: string;
  category: string;
}) => {
  const { data, isLoading, error, isError } = useQuery({
    queryKey: ["tmdb", type, language, category],
    queryFn: () => fetchTmdbSeriesList(type, {
      mediaType: 'all',
      language,
      category,
    }),
    staleTime: 1000 * 60 * 60 * 24, // Cache for 24 hours
    retry: 3,
    retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
    refetchOnWindowFocus: false,
  });

  // Show loading skeleton even on error (retrying)
  if (isLoading || (isError && !data)) {
    return (
      <section className="space-y-4">
        <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="overflow-hidden border-border">
              <CardContent className="p-0">
                <Skeleton className="aspect-[2/3] w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    );
  }

  // Filter by language and category
  // Note: Backend also filters, but we do it here too as a safety net
  const seriesList =
    data?.results.filter((item) => {
      // Language filtering using proper matching logic
      if (language !== "all") {
        const itemLanguage = item.language || item.languages || item.original_language || "";
        if (!matchesLanguage(language, itemLanguage)) {
          return false;
        }
      }

      // Category filtering
      if (category !== "all") {
        const genresArray =
          item.genres?.map((g: any) => g.name?.toLowerCase?.()) ||
          item.genre?.toLowerCase?.().split(",").map((g: string) => g.trim()) ||
          [];
        return genresArray.some((genre: string) => genre && genre.includes(category.toLowerCase()));
      }

      return true;
    }) || [];

  // Debug logging
  if (seriesList.length > 0 && process.env.NODE_ENV === 'development') {
    console.log(`${type} results:`, seriesList.length, seriesList.slice(0, 2).map(s => ({ 
      name: s.name || s.title, 
      poster: s.poster_path ? 'has poster' : 'no poster' 
    })));
  }

  return (
    <section className="space-y-4">
      <h2 className="text-2xl md:text-3xl font-bold">{title}</h2>
      {seriesList.length === 0 ? (
        // Empty state - show placeholder cards that look professional
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="overflow-hidden border-border opacity-50">
              <CardContent className="p-0">
                <div className="aspect-[2/3] bg-muted flex items-center justify-center">
                  <div className="text-center p-4">
                    <div className="w-12 h-12 rounded-full bg-muted-foreground/20 mx-auto mb-2" />
                    <div className="h-3 w-20 bg-muted-foreground/20 rounded mx-auto mb-1" />
                    <div className="h-2 w-16 bg-muted-foreground/10 rounded mx-auto" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {seriesList.slice(0, 24).map((series, index) => (
            <motion.div
              key={series.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.02 }}
            >
              <Link to={`/${series.media_type === 'movie' ? 'movie' : 'series'}/${series.id}`}>
                <Card className="overflow-hidden hover:scale-[1.02] transition-transform cursor-pointer border-border group">
                  <CardContent className="p-0">
                    <div className="aspect-[2/3] relative bg-muted overflow-hidden">
                      {normalizeImageUrl(series.poster_path) ? (
                        <img
                          src={normalizeImageUrl(series.poster_path)!}
                          alt={series.name || series.title || "Poster"}
                          className="h-full w-full object-cover group-hover:brightness-110 transition-all"
                          loading="lazy"
                          onError={(e) => {
                            // Fallback if image fails to load
                            const target = e.target as HTMLImageElement;
                            target.style.display = "none";
                            const parent = target.parentElement;
                            if (parent) {
                              const existingFallback = parent.querySelector(".fallback-text");
                              if (!existingFallback) {
                                const fallback = document.createElement("div");
                                fallback.className = "fallback-text h-full w-full bg-muted flex items-center justify-center absolute inset-0";
                                fallback.innerHTML = `<p class="text-muted-foreground text-xs text-center px-2">${series.name || series.title || "No Image"}</p>`;
                                parent.appendChild(fallback);
                              }
                            }
                          }}
                          onLoad={(e) => {
                            // Hide any fallback when image loads successfully
                            const target = e.target as HTMLImageElement;
                            const parent = target.parentElement;
                            if (parent) {
                              const fallback = parent.querySelector(".fallback-text");
                              if (fallback) {
                                fallback.remove();
                              }
                            }
                          }}
                        />
                      ) : (
                        <div className="h-full w-full bg-muted flex items-center justify-center">
                          <p className="text-muted-foreground text-xs text-center px-2">
                            {series.name || series.title}
                          </p>
                        </div>
                      )}
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-2 space-y-1">
                        <p className="text-xs font-semibold text-white line-clamp-2">
                          {series.name || series.title}
                        </p>
                        <div className="flex items-center justify-between text-[10px] text-white/80">
                          <span>⭐ {series.vote_average?.toFixed(1) || "N/A"}</span>
                          <span className="uppercase text-[9px]">
                            {series.media_type === 'movie' ? 'Movie' : 'TV'}
                          </span>
                          {(series.first_air_date || series.release_date) && (
                            <span>{new Date(series.first_air_date || series.release_date!).getFullYear()}</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </section>
  );
};

const Index = () => {
  const [selectedLanguage, setSelectedLanguage] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8 space-y-12">
        <motion.section
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-4xl md:text-5xl font-bold">CineVerse</h1>
              <p className="text-muted-foreground max-w-2xl text-lg mt-2">
                The universe of movies and series—organized for you. Discover, track, and share your favorites with real-time
                OMDB data, personalized watchlists, and social features.
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2">
                <Globe className="h-5 w-5 text-muted-foreground" />
                <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Language" />
                  </SelectTrigger>
                  <SelectContent>
                    {LANGUAGES.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        {lang.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </motion.section>

        <SeriesSection
          title="Trending Now"
          type="trending"
          language={selectedLanguage}
          category={selectedCategory}
        />
        <SeriesSection
          title="Popular TV & Movies"
          type="popular"
          language={selectedLanguage}
          category={selectedCategory}
        />
        <SeriesSection
          title="Top Rated"
          type="top_rated"
          language={selectedLanguage}
          category={selectedCategory}
        />
        <SeriesSection
          title="Upcoming & Airing"
          type="upcoming"
          language={selectedLanguage}
          category={selectedCategory}
        />
      </div>
    </div>
  );
};

export default Index;
