import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { fetchTmdbMovieDetails } from "@/integrations/supabase/tmdb";
import { toast } from "sonner";
import { Check, Star, Clock, Calendar, Users, Eye, BookmarkPlus, DollarSign } from "lucide-react";
import { motion } from "framer-motion";
import { addToWatchlist, getItemStatus, removeFromWatchlist } from "@/lib/watchlist";

const MovieDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [isWatched, setIsWatched] = useState(false);
  const [isPlanToWatch, setIsPlanToWatch] = useState(false);
  const [userRating, setUserRating] = useState<number | null>(null);

  const {
    data: movie,
    isLoading,
    error,
  } = useQuery({
    queryKey: ["tmdb-movie", id],
    queryFn: () => fetchTmdbMovieDetails(id!),
    enabled: !!id,
    retry: 2,
    retryDelay: 1000,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    loadStoredStatus();
  }, [id]);

  const loadStoredStatus = () => {
    if (!id) return;
    const status = getItemStatus(Number(id), "movie");
    setIsWatched(status === "watched");
    setIsPlanToWatch(status === "planned");
  };

  const handleMarkWatched = () => {
    if (!id || !movie) return;
    const numId = Number(id);
    
    if (isWatched) {
      removeFromWatchlist(numId, "movie");
      setIsWatched(false);
      setIsPlanToWatch(false);
      toast.success("Removed from watched");
    } else {
      addToWatchlist({
        id: numId,
        media_type: "movie",
        status: "watched",
        name: movie.title || "Unknown",
        poster_path: movie.poster_path,
        vote_average: movie.vote_average || 0,
        year: movie.release_date?.substring(0, 4) || null,
      });
      setIsWatched(true);
      setIsPlanToWatch(false);
      toast.success("Marked as watched!");
    }
  };

  const handlePlanToWatch = () => {
    if (!id || !movie) return;
    const numId = Number(id);
    
    if (isPlanToWatch) {
      removeFromWatchlist(numId, "movie");
      setIsPlanToWatch(false);
      setIsWatched(false);
      toast.success("Removed from watchlist");
    } else {
      addToWatchlist({
        id: numId,
        media_type: "movie",
        status: "planned",
        name: movie.title || "Unknown",
        poster_path: movie.poster_path,
        vote_average: movie.vote_average || 0,
        year: movie.release_date?.substring(0, 4) || null,
      });
      setIsPlanToWatch(true);
      setIsWatched(false);
      toast.success("Added to watchlist!");
    }
  };

  const handleRate = (rating: number) => {
    if (!id) return;
    const ratingKey = `cineverse_ratings`;
    try {
      const stored = localStorage.getItem(ratingKey);
      const ratings = stored ? JSON.parse(stored) : {};
      localStorage.setItem(ratingKey, JSON.stringify({ ...ratings, [`movie_${id}`]: rating }));
    } catch {
      localStorage.setItem(ratingKey, JSON.stringify({ [`movie_${id}`]: rating }));
    }
    setUserRating(rating);
    toast.success(`Rated ${rating}/10`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8 space-y-6">
          <Skeleton className="h-96 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    );
  }

  if (error || !movie) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="p-12 text-center">
              <p className="text-muted-foreground text-lg mb-4">Unable to load movie details at this time.</p>
              <Button onClick={() => window.location.reload()}>Try Again</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const trailer = movie.videos?.results?.find((v: any) => v.site === "YouTube" && v.type === "Trailer");
  const runtime = movie.runtime ? `${Math.floor(movie.runtime / 60)}h ${movie.runtime % 60}m` : null;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="relative">
        {movie.backdrop_path && (
          <div className="absolute inset-0 h-[60vh] overflow-hidden">
            <img src={movie.backdrop_path} alt={movie.title} className="w-full h-full object-cover opacity-20" />
            <div className="absolute inset-0 bg-gradient-to-b from-background/80 to-background" />
          </div>
        )}
        <div className="container mx-auto px-4 py-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col md:flex-row gap-6"
          >
            {movie.poster_path && (
              <img
                src={movie.poster_path}
                alt={movie.title}
                className="w-full md:w-80 h-auto rounded-lg border border-border"
              />
            )}
            <div className="flex-1 space-y-4">
              <div>
                <h1 className="text-4xl font-bold mb-2">{movie.title}</h1>
                <div className="flex flex-wrap gap-2 items-center text-muted-foreground">
                  <span>⭐ {movie.vote_average?.toFixed(1)}</span>
                  {runtime && (
                    <>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {runtime}
                      </span>
                    </>
                  )}
                  {movie.release_date && (
                    <>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(movie.release_date).getFullYear()}
                      </span>
                    </>
                  )}
                  {movie.budget && movie.budget > 0 && (
                    <>
                      <span>•</span>
                      <span className="flex items-center gap-1">
                        <DollarSign className="h-4 w-4" />
                        Budget: ${(movie.budget / 1000000).toFixed(1)}M
                      </span>
                    </>
                  )}
                </div>
                {movie.status && (
                  <Badge variant="outline" className="mt-2">
                    {movie.status}
                  </Badge>
                )}
              </div>

              <div className="flex flex-wrap gap-2">
                {movie.genres?.map((genre: any) => (
                  <Badge key={genre.id} variant="secondary">
                    {genre.name}
                  </Badge>
                ))}
              </div>

              <p className="text-lg leading-relaxed">{movie.overview}</p>

              {movie.tagline && <p className="text-muted-foreground italic">"{movie.tagline}"</p>}

              <div className="flex flex-wrap gap-3">
                <Button
                  onClick={handleMarkWatched}
                  variant={isWatched ? "default" : "outline"}
                  className={isWatched ? "bg-red-600 hover:bg-red-700 text-white" : ""}
                >
                  {isWatched ? <Check className="mr-2 h-4 w-4" /> : <Eye className="mr-2 h-4 w-4" />}
                  {isWatched ? "Already Watched" : "Mark as Watched"}
                </Button>
                <Button onClick={handlePlanToWatch} variant={isPlanToWatch ? "default" : "outline"}>
                  <BookmarkPlus className="mr-2 h-4 w-4" />
                  {isPlanToWatch ? "In Watchlist" : "Plan to Watch"}
                </Button>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">Your Rating</p>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((rating) => (
                    <button
                      key={rating}
                      onClick={() => handleRate(rating)}
                      className={`p-2 rounded ${
                        userRating === rating ? "bg-primary text-primary-foreground" : "bg-muted hover:bg-muted/80"
                      }`}
                    >
                      <Star className="h-4 w-4" fill={userRating === rating ? "currentColor" : "none"} />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {trailer && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="mt-8">
              <h2 className="text-2xl font-bold mb-4">Trailer</h2>
              <div className="aspect-video rounded-lg overflow-hidden border border-border">
                <iframe className="w-full h-full" src={`https://www.youtube.com/embed/${trailer.key}`} allowFullScreen />
              </div>
            </motion.div>
          )}

          <Tabs defaultValue="cast" className="mt-8">
            <TabsList>
              <TabsTrigger value="cast">Cast</TabsTrigger>
              <TabsTrigger value="crew">Crew</TabsTrigger>
              <TabsTrigger value="images">Images</TabsTrigger>
            </TabsList>

            <TabsContent value="cast" className="space-y-4">
              {movie.credits?.cast && movie.credits.cast.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {movie.credits.cast.slice(0, 18).map((member: any, index: number) => (
                    <Card key={member.id || index}>
                      <CardContent className="p-0">
                        {member.profile_path ? (
                          <img
                            src={member.profile_path}
                            alt={member.name}
                            className="w-full aspect-[2/3] object-cover rounded-t-lg"
                          />
                        ) : (
                          <div className="w-full aspect-[2/3] bg-muted flex items-center justify-center rounded-t-lg">
                            <Users className="h-8 w-8 text-muted-foreground" />
                          </div>
                        )}
                        <div className="p-2">
                          <p className="text-sm font-medium line-clamp-1">{member.name}</p>
                          <p className="text-xs text-muted-foreground line-clamp-1">{member.character}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="p-8 text-center">
                    <p className="text-muted-foreground">No cast information available.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="crew" className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {movie.credits?.crew
                  ?.filter((c: any) => c.job === "Director" || c.job === "Producer" || c.job === "Writer")
                  .slice(0, 12)
                  .map((member: any, index: number) => (
                    <Card key={`${member.id}-${member.job}-${index}`}>
                      <CardContent className="p-4">
                        <p className="font-medium">{member.name}</p>
                        <p className="text-sm text-muted-foreground">{member.job}</p>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="images" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {movie.images?.backdrops?.slice(0, 12).map((img: any, index: number) => (
                  <img
                    key={index}
                    src={`https://image.tmdb.org/t/p/w780${img.file_path}`}
                    alt={`${movie.title} backdrop ${index + 1}`}
                    className="w-full h-48 object-cover rounded-lg border border-border"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = "none";
                    }}
                  />
                ))}
              </div>
              {(!movie.images?.backdrops || movie.images.backdrops.length === 0) && (
                <Card>
                  <CardContent className="p-8 text-center">
                    <p className="text-muted-foreground">No images available.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default MovieDetail;
