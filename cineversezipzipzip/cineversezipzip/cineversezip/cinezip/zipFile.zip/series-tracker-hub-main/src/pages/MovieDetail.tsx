import { useParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { fetchTmdbMovieDetails } from "@/integrations/supabase/tmdb";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Plus, Check, Star, Play, Calendar, Users, Film } from "lucide-react";
import { motion } from "framer-motion";
import { normalizeImageUrl } from "@/lib/utils";

// OMDB provides direct poster URLs

const MovieDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [isInWatchlist, setIsInWatchlist] = useState(false);
  const [userRating, setUserRating] = useState<number | null>(null);

  const { data: movie, isLoading, error } = useQuery({
    queryKey: ["tmdb-movie", id],
    queryFn: () => fetchTmdbMovieDetails(id!),
    enabled: !!id,
    retry: 2,
    retryDelay: 1000,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    checkUserData();
  }, [id]);

  const checkUserData = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user || !id) return;

    // Check watchlist
    const { data: watchlist } = await supabase
      .from("user_watchlist")
      .select("*")
      .eq("user_id", user.id)
      .eq("series_id", parseInt(id))
      .single();

    setIsInWatchlist(!!watchlist);

    // Check rating
    const { data: rating } = await supabase
      .from("user_ratings")
      .select("rating")
      .eq("user_id", user.id)
      .eq("series_id", parseInt(id))
      .single();

    setUserRating(rating?.rating || null);
  };

  const handleWatchlist = async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user || !id) {
      toast.error("Please login to add to watchlist");
      return;
    }

    if (isInWatchlist) {
      const { error } = await supabase
        .from("user_watchlist")
        .delete()
        .eq("user_id", user.id)
        .eq("series_id", parseInt(id));
      if (!error) {
        setIsInWatchlist(false);
        toast.success("Removed from watchlist");
      }
    } else {
      const { error } = await supabase.from("user_watchlist").insert({
        user_id: user.id,
        series_id: parseInt(id),
      });
      if (!error) {
        setIsInWatchlist(true);
        toast.success("Added to watchlist");
      }
    }
  };

  const handleRate = async (rating: number) => {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user || !id) {
      toast.error("Please login to rate");
      return;
    }

    const { error } = await supabase.from("user_ratings").upsert({
      user_id: user.id,
      series_id: parseInt(id),
      rating,
    });

    if (!error) {
      setUserRating(rating);
      toast.success(`Rated ${rating}/10`);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8 space-y-6">
          <Skeleton className="h-96 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    );
  }

  if (error || !movie) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="p-12 text-center">
              <p className="text-muted-foreground text-lg mb-4">
                Unable to load movie details at this time.
              </p>
              <Button onClick={() => window.location.reload()}>Try Again</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const trailer = movie.videos?.results?.find(
    (v: any) => v.site === "YouTube" && v.type === "Trailer"
  );

  const runtime = movie.runtime ? `${Math.floor(movie.runtime / 60)}h ${movie.runtime % 60}m` : null;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="relative">
        {normalizeImageUrl(movie.backdrop_path || movie.poster_path) && (
          <div className="absolute inset-0 h-[60vh] overflow-hidden">
            <img
              src={normalizeImageUrl(movie.backdrop_path || movie.poster_path)!}
              alt={movie.title}
              className="w-full h-full object-cover opacity-20"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-background/80 to-background" />
          </div>
        )}
        <div className="container mx-auto px-4 py-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col md:flex-row gap-6"
          >
            {normalizeImageUrl(movie.poster_path) && (
              <img
                src={normalizeImageUrl(movie.poster_path)!}
                alt={movie.title}
                className="w-full md:w-80 h-auto rounded-lg border border-border"
              />
            )}
            <div className="flex-1 space-y-4">
              <div>
                <h1 className="text-4xl font-bold mb-2">{movie.title}</h1>
                <div className="flex flex-wrap gap-2 items-center text-muted-foreground">
                  <span>⭐ {movie.vote_average?.toFixed(1)}</span>
                  {runtime && (
                    <>
                      <span>•</span>
                      <span>{runtime}</span>
                    </>
                  )}
                  {movie.release_date && (
                    <>
                      <span>•</span>
                      <span>{new Date(movie.release_date).getFullYear()}</span>
                    </>
                  )}
                  {movie.budget && movie.budget > 0 && (
                    <>
                      <span>•</span>
                      <span>Budget: ${(movie.budget / 1000000).toFixed(1)}M</span>
                    </>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {movie.genres?.map((genre: any) => (
                  <Badge key={genre.id} variant="secondary">
                    {genre.name}
                  </Badge>
                ))}
              </div>

              <p className="text-lg leading-relaxed">{movie.overview}</p>

              {movie.tagline && (
                <p className="text-muted-foreground italic">"{movie.tagline}"</p>
              )}

              <div className="flex flex-wrap gap-2">
                <Button onClick={handleWatchlist} variant={isInWatchlist ? "default" : "outline"}>
                  {isInWatchlist ? <Check className="mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
                  {isInWatchlist ? "In Watchlist" : "Add to Watchlist"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    toast.success("Marked as watched!");
                  }}
                >
                  <Play className="mr-2 h-4 w-4" />
                  Mark as Watched
                </Button>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">Your Rating</p>
                <div className="flex gap-1">
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((rating) => (
                    <button
                      key={rating}
                      onClick={() => handleRate(rating)}
                      className={`p-2 rounded ${
                        userRating === rating
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted hover:bg-muted/80"
                      }`}
                    >
                      <Star className="h-4 w-4" fill={userRating === rating ? "currentColor" : "none"} />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {trailer && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mt-8"
            >
              <h2 className="text-2xl font-bold mb-4">Trailer</h2>
              <div className="aspect-video rounded-lg overflow-hidden border border-border">
                <iframe
                  className="w-full h-full"
                  src={`https://www.youtube.com/embed/${trailer.key}`}
                  allowFullScreen
                />
              </div>
            </motion.div>
          )}

          <Tabs defaultValue="cast" className="mt-8">
            <TabsList>
              <TabsTrigger value="cast">Cast</TabsTrigger>
              <TabsTrigger value="crew">Crew</TabsTrigger>
              <TabsTrigger value="images">Images</TabsTrigger>
            </TabsList>

            <TabsContent value="cast" className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                {movie.credits?.cast?.slice(0, 20).map((member: any) => (
                  <Card key={member.id}>
                    <CardContent className="p-0">
                      {member.profile_path ? (
                        <img
                          src={member.profile_path || undefined}
                          alt={member.name}
                          className="w-full aspect-[2/3] object-cover rounded-t-lg"
                        />
                      ) : (
                        <div className="w-full aspect-[2/3] bg-muted flex items-center justify-center rounded-t-lg">
                          <Users className="h-8 w-8 text-muted-foreground" />
                        </div>
                      )}
                      <div className="p-2">
                        <p className="text-xs font-medium line-clamp-1">{member.name}</p>
                        <p className="text-xs text-muted-foreground line-clamp-1">
                          {member.character}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="crew" className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {movie.credits?.crew
                  ?.filter((c: any) => c.job === "Director" || c.job === "Producer")
                  .slice(0, 10)
                  .map((member: any) => (
                    <Card key={member.id}>
                      <CardContent className="p-4">
                        <p className="font-medium">{member.name}</p>
                        <p className="text-sm text-muted-foreground">{member.job}</p>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="images" className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {movie.images?.backdrops?.slice(0, 12).map((img: any, index: number) => (
                  <img
                    key={index}
                    src={normalizeImageUrl(img.file_path || img.poster_path) || ""}
                    alt={`${movie.title} backdrop ${index + 1}`}
                    className="w-full h-48 object-cover rounded-lg border border-border"
                  />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default MovieDetail;


